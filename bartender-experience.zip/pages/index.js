
import Head from 'next/head';
import BartenderExperience from '@/components/BartenderExperience';

export default function Home() {
  return (
    <>
      <Head>
        <title>Bartender Profesional</title>
      </Head>
      <main>
        <BartenderExperience />
      </main>
    </>
  );
}

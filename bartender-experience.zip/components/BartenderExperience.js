
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import Image from "next/image";

const screens = [
  {
    id: "intro",
    title: "Bienvenido al Universo del Bartender",
    content: "Sumérgete en una experiencia donde cada copa cuenta una historia.",
    image: "/images/intro.jpg"
  },
  {
    id: "manifiesto",
    title: "Manifiesto del Sabor",
    content: "No solo sirvo tragos. Creo momentos líquidos que despiertan emociones.",
    image: "/images/manifiesto.jpg"
  },
  {
    id: "servicios",
    title: "Servicios a tu Medida",
    content: "Desde barras personalizadas hasta mixología molecular, tu evento será inolvidable.",
    image: "/images/servicios.jpg"
  },
  {
    id: "galeria",
    title: "Galería de Experiencias",
    content: "Explora un mundo visual de cócteles, eventos y arte líquido.",
    image: "/images/galeria.jpg"
  },
  {
    id: "contacto",
    title: "Reserva una Experiencia",
    content: "¿Listo para agitar la noche? Contáctame y hagamos magia.",
    image: "/images/contacto.jpg"
  }
];

export default function BartenderExperience() {
  const [screenIndex, setScreenIndex] = useState(0);
  const audioRef = useRef(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.3;
      audioRef.current.play().catch(() => {});
    }
  }, []);

  const next = () => setScreenIndex((i) => (i + 1) % screens.length);
  const prev = () => setScreenIndex((i) => (i - 1 + screens.length) % screens.length);

  const current = screens[screenIndex];

  return (
    <div className="h-screen w-full relative overflow-hidden bg-black text-white">
      <audio ref={audioRef} loop>
        <source src="/audio/jazz.mp3" type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>

      <Image
        src={current.image}
        alt="background"
        layout="fill"
        objectFit="cover"
        className="z-0 opacity-30 blur-sm"
      />
      <div className="absolute inset-0 bg-black/60 z-10" />
      <div className="relative z-20 h-full w-full flex flex-col items-center justify-center p-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={current.id}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-xl"
          >
            <h1 className="text-4xl font-bold mb-4 text-fuchsia-400 drop-shadow-lg">{current.title}</h1>
            <p className="text-lg text-gray-200 drop-shadow-md">{current.content}</p>
          </motion.div>
        </AnimatePresence>

        <div className="absolute bottom-10 flex gap-4">
          <Button onClick={prev} variant="outline" className="text-white border-white bg-black/50 hover:bg-black/70">Anterior</Button>
          <Button onClick={next} variant="default" className="bg-fuchsia-600 hover:bg-fuchsia-700">Siguiente</Button>
        </div>
      </div>
    </div>
  );
}
